package dev.dirronlive.sky.core;

/**
 * Зона помощи в полёте: восходящий поток ({@code LIFT}) поднимает игрока,
 * пока он внутри прямоугольной области.
 */
public record Zone(Kind kind, V3 min, V3 max, double strength) {
    public enum Kind { LIFT }

    public Zone {
        V3 a = min, b = max;
        min = new V3(Math.min(a.x(), b.x()), Math.min(a.y(), b.y()), Math.min(a.z(), b.z()));
        max = new V3(Math.max(a.x(), b.x()), Math.max(a.y(), b.y()), Math.max(a.z(), b.z()));
    }

    public boolean contains(V3 p) {
        return p.x() >= min.x() && p.x() <= max.x() && p.y() >= min.y() && p.y() <= max.y()
                && p.z() >= min.z() && p.z() <= max.z();
    }
}
