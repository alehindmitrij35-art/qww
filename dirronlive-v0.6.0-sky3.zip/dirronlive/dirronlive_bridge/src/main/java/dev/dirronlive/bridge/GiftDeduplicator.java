package dev.dirronlive.bridge;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Помнит ID уже показанных подарков, чтобы повторно присланный подарок
 * подтвердить ещё раз, но не показывать второй раз. Хранит последние
 * {@code capacity} ID. Используется только из игрового потока.
 */
public final class GiftDeduplicator {
    private final Map<String, Boolean> seen;

    public GiftDeduplicator(int capacity) {
        this.seen = new LinkedHashMap<>(64, 0.75f, false) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<String, Boolean> eldest) {
                return size() > capacity;
            }
        };
    }

    public boolean contains(String id) {
        return seen.containsKey(id);
    }

    public void remember(String id) {
        seen.put(id, Boolean.TRUE);
    }

    public int size() {
        return seen.size();
    }
}
