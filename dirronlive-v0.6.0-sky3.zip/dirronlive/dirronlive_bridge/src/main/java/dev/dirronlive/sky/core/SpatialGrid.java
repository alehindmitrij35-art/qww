package dev.dirronlive.sky.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Пространственный индекс: мир разбит на кубы {@code CELL}×{@code CELL}×{@code CELL},
 * объект лежит во всех кубах, которые задевает. Поиск рядом с точкой — одна
 * ячейка, без перебора всей трассы.
 */
public final class SpatialGrid<T> {
    public static final int CELL = 16;
    private final Map<Long, List<T>> cells = new HashMap<>();
    private int size;

    static long key(int cx, int cy, int cz) {
        return ((long) (cx & 0x1FFFFF) << 42) | ((long) (cy & 0x1FFFFF) << 21) | (cz & 0x1FFFFF);
    }

    static int cell(double v) {
        return (int) Math.floor(v / CELL);
    }

    public void add(V3 min, V3 max, T item) {
        for (int cx = cell(min.x()); cx <= cell(max.x()); cx++)
            for (int cy = cell(min.y()); cy <= cell(max.y()); cy++)
                for (int cz = cell(min.z()); cz <= cell(max.z()); cz++)
                    cells.computeIfAbsent(key(cx, cy, cz), k -> new ArrayList<>(2)).add(item);
        size++;
    }

    /** Объекты в ячейке точки (без копирования; не изменять). */
    public List<T> at(V3 p) {
        List<T> list = cells.get(key(cell(p.x()), cell(p.y()), cell(p.z())));
        return list == null ? Collections.emptyList() : list;
    }

    /** Объекты в радиусе {@code r} ячеек вокруг точки (для отрисовки рядом с камерой). */
    public Set<T> near(V3 p, double radius) {
        Set<T> out = new LinkedHashSet<>();
        int r = (int) Math.ceil(radius / CELL);
        int px = cell(p.x()), py = cell(p.y()), pz = cell(p.z());
        for (int cx = px - r; cx <= px + r; cx++)
            for (int cy = py - r; cy <= py + r; cy++)
                for (int cz = pz - r; cz <= pz + r; cz++) {
                    List<T> list = cells.get(key(cx, cy, cz));
                    if (list != null) out.addAll(list);
                }
        return out;
    }

    public int size() {
        return size;
    }
}
