#!/usr/bin/env bash
# Сборка мода Dirronlive Bridge, проверки карт в настоящем Minecraft и
# сборка готовых миров DirronParkour и DirronSky. Запускается на GitHub из папки
# dirronlive/dirronlive_bridge. Итог — build/installer/*.zip и *.jar.
set -u
chmod +x gradlew
status=0
mkdir -p build/installer

note() { echo "::notice title=$1::$2"; }
err() { echo "::error title=$1::$2"; }
# Сводка на странице запуска (видна без входа в GitHub).
summary() { echo "$1" >> "${GITHUB_STEP_SUMMARY:-/dev/null}"; }
summary "## Мод Dirronlive Bridge и карта Dirron Parkour"

# 1. Сборка и обычные тесты (протокол, генератор 100 комнат).
./gradlew build --stacktrace --no-daemon 2>&1 | tee build.log
if [ "${PIPESTATUS[0]}" -ne 0 ]; then
  grep -E "error:|FAILED|BUILD FAILED|What went wrong" -A3 build.log | head -60 | while IFS= read -r line; do
    err "mod build" "$line"
  done
  exit 1
fi
passed=$(grep -c " PASSED$" build.log || true)
failed=$(grep -c " FAILED$" build.log || true)
note "mod test" "обычные тесты мода: прошло ${passed}, упало ${failed}"
summary "- Обычные тесты мода (протокол, генератор 100 комнат): прошло **${passed}**, упало **${failed}**"

jar=$(ls build/libs/DirronliveBridge-*.jar | grep -v -- '-sources' | head -1)
nested=$(unzip -l "$jar" | grep -c "META-INF/jars/")
note "mod jar" "$(basename "$jar"): $(stat -c%s "$jar") bytes, вложенных модулей Fabric API: ${nested}"
summary "- Мод: \`$(basename "$jar")\`, $(stat -c%s "$jar") байт, модулей Fabric API внутри: ${nested}"
unzip -l "$jar" | grep -q "fabric.mod.json" || { err "mod jar" "нет fabric.mod.json"; exit 1; }
[ "$nested" -ge 3 ] || { err "mod jar" "модули Fabric API не упакованы внутрь"; exit 1; }
if unzip -l "$jar" | grep -q "META-INF/jars/fabric-gametest"; then
  err "mod jar" "в jar попал модуль gametest"; status=1
fi
cp "$jar" build/installer/

# 2. Проверки карты внутри Minecraft 1.21.1 (сервер GameTest).
./gradlew runGametest --no-daemon 2>&1 | tee gametest.log
checks=$(grep -cE "(PARKOUR|SKY)_CHECK" gametest.log || true)
oks=$(grep -cE "(PARKOUR|SKY)_CHECK ok" gametest.log || true)
skychecks=$(grep -c "SKY_CHECK" gametest.log || true)
note "в игре" "проверок в Minecraft 1.21.1: ${oks} из ${checks} OK, из них «Небесный разлом»: ${skychecks} (подробно — в сводке запуска)"
summary ""
summary "### Проверки в настоящем Minecraft 1.21.1 (GameTest)"
grep -E "(PARKOUR|SKY)_CHECK" gametest.log | sed -E 's/.*(PARKOUR|SKY)_CHECK //' | while IFS= read -r line; do
  case "$line" in
    ok*) summary "- ✅ ${line#ok | }" ;;
    *) summary "- ❌ ${line#fail | }"; err "в игре: ОШИБКА" "${line#fail | }" ;;
  esac
done
if grep -qE "(PARKOUR|SKY)_CHECK fail" gametest.log; then status=1; fi
[ "$skychecks" -gt 0 ] || { err "в игре" "проверки «Небесного разлома» не запустились"; status=1; }
if [ "$checks" -eq 0 ]; then
  err "в игре" "проверки GameTest не запустились"
  grep -E "Exception|Error|FAILED|failed" gametest.log | head -30 | while IFS= read -r line; do err "gametest log" "$line"; done
  status=1
fi
if [ -f build/gametest/report.xml ]; then
  python3 - <<'PY' || status=1
import os, sys
import xml.etree.ElementTree as ET
root = ET.parse('build/gametest/report.xml').getroot()
cases = root.iter('testcase')
total = failed = 0
for c in cases:
    total += 1
    f = c.find('failure')
    if f is not None:
        failed += 1
        print(f"::error title=GameTest {c.get('name')}::{(f.get('message') or '')[:500]}")
print(f"::notice title=GameTest::{total - failed} из {total} проверок прошли")
with open(os.environ.get('GITHUB_STEP_SUMMARY', os.devnull), 'a', encoding='utf-8') as f:
    f.write(f"\n**GameTest: {total - failed} из {total} тестов прошли**\n")
sys.exit(1 if failed else 0)
PY
fi

# 3. Готовый мир DirronParkour (выделенный сервер строит карту и выключается).
./gradlew worldZip --no-daemon 2>&1 | tee world.log
if grep -q "DIRRON_WORLD_BUILT" world.log && [ -f build/installer/DirronParkour-world.zip ]; then
  note "мир" "$(grep -o 'DIRRON_WORLD_BUILT.*' world.log | head -1), архив $(stat -c%s build/installer/DirronParkour-world.zip) bytes"
  summary ""
  summary "### Мир DirronParkour"
  summary "- $(grep -o 'DIRRON_WORLD_BUILT.*' world.log | head -1)"
  summary "- \`DirronParkour-world.zip\`: $(stat -c%s build/installer/DirronParkour-world.zip) байт, файлов: $(unzip -l build/installer/DirronParkour-world.zip | tail -1 | awk '{print $2}')"
  unzip -l build/installer/DirronParkour-world.zip | grep -q "DirronParkour/level.dat" || { err "мир" "нет level.dat"; status=1; }
  unzip -l build/installer/DirronParkour-world.zip | grep -q "DirronParkour/region/" || { err "мир" "нет region"; status=1; }
else
  err "мир" "мир не построен"
  grep -E "Exception|Error|FAILED" world.log | head -30 | while IFS= read -r line; do err "world log" "$line"; done
  status=1
fi

# 3б. Готовый мир DirronSky — «Небесный разлом» (острова и трасса из колец).
./gradlew skyWorldZip --no-daemon 2>&1 | tee skyworld.log
if grep -q "DIRRON_SKY_BUILT" skyworld.log && [ -f build/installer/DirronSky-world.zip ]; then
  note "мир неба" "$(grep -o 'DIRRON_SKY_BUILT.*' skyworld.log | head -1), архив $(stat -c%s build/installer/DirronSky-world.zip) bytes"
  summary ""
  summary "### Мир DirronSky («Небесный разлом»)"
  summary "- $(grep -o 'DIRRON_SKY_BUILT.*' skyworld.log | head -1)"
  summary "- \`DirronSky-world.zip\`: $(stat -c%s build/installer/DirronSky-world.zip) байт"
  unzip -l build/installer/DirronSky-world.zip | grep -q "DirronSky/level.dat" || { err "мир неба" "нет level.dat"; status=1; }
  unzip -l build/installer/DirronSky-world.zip | grep -q "DirronSky/dirron_sky/track.json" || { err "мир неба" "нет трассы"; status=1; }
  grep -q "problems=0" skyworld.log || { err "мир неба" "в трассе есть проблемы"; status=1; }
else
  err "мир неба" "мир DirronSky не построен"
  grep -E "Exception|Error|FAILED" skyworld.log | head -30 | while IFS= read -r line; do err "sky world log" "$line"; done
  status=1
fi

# 4. Набор «всё в одном»: мод + миры + инструкция.
if [ -f build/installer/DirronParkour-world.zip ]; then
  rm -rf build/kit && mkdir -p build/kit/mods build/kit/saves
  cp "$jar" build/kit/mods/
  (cd build/kit/saves && unzip -q ../../installer/DirronParkour-world.zip)
  if [ -f build/installer/DirronSky-world.zip ]; then (cd build/kit/saves && unzip -q ../../installer/DirronSky-world.zip); fi
  cp ../tools/parkour-kit-readme.txt "build/kit/Как установить.txt"
  (cd build/kit && zip -q -r ../installer/DirronParkour-kit.zip .)
  note "набор" "DirronParkour-kit.zip: $(stat -c%s build/installer/DirronParkour-kit.zip) bytes"
  summary "- \`DirronParkour-kit.zip\` (мод + мир + инструкция): $(stat -c%s build/installer/DirronParkour-kit.zip) байт"
fi

ls -la build/installer
exit $status
