// Оверлеи: одна обработанная лента событий → статистика → модели для
// страниц TikTok LIVE Studio и предпросмотра; локальный сервер ссылок.

import 'dart:convert';
import 'dart:io';

import 'package:dirronlive/bootstrap.dart';
import 'package:dirronlive/core/events/event_source.dart';
import 'package:dirronlive/core/events/gift_event.dart';
import 'package:dirronlive/core/events/stream_events.dart';
import 'package:dirronlive/core/initial_data.dart';
import 'package:dirronlive/core/providers.dart';
import 'package:dirronlive/features/overlays/overlay_kind.dart';
import 'package:dirronlive/features/overlays/overlay_models.dart';
import 'package:dirronlive/features/overlays/overlay_server.dart';
import 'package:dirronlive/features/overlays/overlay_settings.dart';
import 'package:dirronlive/features/overlays/stream_stats.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/memory_store.dart';
import 'support/test_app.dart';

Future<ProviderContainer> _container([MemoryJsonStore? store]) async =>
    createAppContainer(await loadInitialData(store ?? MemoryJsonStore()));

GiftEvent _gift(String name, int count,
        {String? combo, bool active = false, EventSource source = EventSource.tiktok, String viewer = 'Alex',
        String? giftId, int diamonds = 1, String? key}) =>
    GiftEvent(
      id: generateEventId(),
      createdAt: DateTime.now(),
      source: source,
      viewerName: viewer,
      viewerId: viewer.toLowerCase(),
      giftName: name,
      giftId: giftId,
      diamonds: diamonds,
      count: count,
      comboId: combo,
      comboActive: active,
      sourceKey: key ?? combo,
    );

Future<void> _settle() => Future<void>.delayed(const Duration(milliseconds: 30));

Map<String, Object?> _model(ProviderContainer c, OverlayKind kind) =>
    buildOverlayModel(kind, c.read(overlayInputsProvider));

void main() {
  test('тестовая серия ×5 обновляет цель и гифт-батл одновременно; повтор не считается', () async {
    final c = await _container();
    final settings = c.read(overlaySettingsProvider.notifier);
    await settings.setTestMode(true);
    await settings.update(OverlayKind.goal, {'type': 'specificGift', 'giftName': 'Роза', 'target': 10});
    await settings.update(OverlayKind.giftBattle, {'leftGift': 'Роза', 'rightGift': 'Сердце', 'running': true});

    final bus = c.read(eventBusProvider);
    for (var n = 1; n <= 5; n++) {
      bus.publish(_gift('Роза', n, combo: 'c1', active: n < 5, source: EventSource.test));
    }
    await _settle();
    // Повтор шагов (как после переподключения).
    bus.publish(_gift('Роза', 5, combo: 'c1', source: EventSource.test));
    bus.publish(_gift('Роза', 3, combo: 'c1', source: EventSource.test));
    await _settle();

    final goal = _model(c, OverlayKind.goal);
    expect(goal['current'], 5);
    expect(goal['label'], 'Осталось 5');
    final battle = _model(c, OverlayKind.giftBattle);
    expect((battle['left'] as Map)['score'], 5);
    expect((battle['right'] as Map)['score'], 0);
    expect(_model(c, OverlayKind.bestCombo)['main'], 'Роза ×5');
    expect(_model(c, OverlayKind.bestCombo)['sub'], 'Alex');

    // Реальный эфир не тронут.
    expect(c.read(streamStatsProvider).live.giftUnits, 0);
    await settings.setTestMode(false);
    expect(_model(c, OverlayKind.goal)['current'], 0);
    c.dispose();
  });

  test('топы, лучший подарок, подписчики, голосование: одна лента, без двойного счёта', () async {
    final c = await _container();
    final bus = c.read(eventBusProvider);
    bus
      ..publish(LikeEvent(viewerId: 'mira', viewerName: 'Mira', likes: 15, sourceKey: 'l1'))
      ..publish(LikeEvent(viewerId: 'mira', viewerName: 'Mira', likes: 15, sourceKey: 'l1')) // повтор
      ..publish(LikeEvent(
          viewerId: 'alex', viewerName: 'Alex', likes: 40, sourceKey: 'l2', viewerAvatar: 'https://p16.tiktokcdn.com/alex.webp'))
      ..publish(_gift('Лев', 1, viewer: 'Mira', giftId: '6064', diamonds: 29999, key: 'msg:1'))
      ..publish(_gift('Роза', 7, viewer: 'Alex', combo: 'r1', giftId: '5655', key: 'group:alex:5655:1'))
      ..publish(_gift('Роза', 7, viewer: 'Alex', combo: 'r2', giftId: '5655', key: 'group:alex:5655:1')) // переподключение
      ..publish(FollowEvent(viewerId: 'neo', viewerName: 'Neo'))
      ..publish(FollowEvent(viewerId: 'neo', viewerName: 'Neo'));
    await _settle();

    final likers = (_model(c, OverlayKind.topLikers)['items'] as List).cast<Map<String, Object?>>();
    expect(likers.map((e) => e['name']), ['Alex', 'Mira']);
    expect(likers.last['value'], '15 ❤');
    // Аватарка зрителя — в топе; у кого её нет, страница покажет букву ника.
    expect(likers.first['avatar'], 'https://p16.tiktokcdn.com/alex.webp');
    expect(likers.last['avatar'], isNull);
    final donors = (_model(c, OverlayKind.topDonors)['items'] as List).cast<Map<String, Object?>>();
    expect(donors.first['name'], 'Mira');
    expect(donors.last['value'], '7 монет');
    expect(_model(c, OverlayKind.bestGift)['main'], 'Лев');
    expect(_model(c, OverlayKind.bestGift)['sub'], 'Mira · 29\u00A0999 монет');
    expect(c.read(streamStatsProvider).live.giftUnits, 8);

    await c.read(overlaySettingsProvider.notifier).update(OverlayKind.goal, {'type': 'newFollowers', 'target': 3});
    expect(_model(c, OverlayKind.goal)['current'], 1);

    // Голосование: последний голос зрителя заменяет предыдущий.
    await c.read(overlaySettingsProvider.notifier).set(OverlayKind.chatVote, 'running', true);
    bus
      ..publish(ChatEvent(viewerId: 'mira', viewerName: 'Mira', text: '1'))
      ..publish(ChatEvent(viewerId: 'alex', viewerName: 'Alex', text: '2'))
      ..publish(ChatEvent(viewerId: 'mira', viewerName: 'Mira', text: '2'))
      ..publish(ChatEvent(viewerId: 'neo', viewerName: 'Neo', text: 'привет'));
    await _settle();
    final vote = _model(c, OverlayKind.chatVote);
    expect(vote['total'], 2);
    expect((vote['options'] as List).cast<Map<String, Object?>>().last['percent'], 100);
    c.dispose();
  });

  test('статистика эфира переживает перезапуск, тот же эфир не считается заново', () async {
    final store = MemoryJsonStore();
    var c = await _container(store);
    c.read(eventBusProvider)
      ..publish(RoomInfoEvent(uniqueId: 'dirron', roomId: 'R1', followers: 100))
      ..publish(_gift('Роза', 5, combo: 'x', key: 'group:alex:5655:9'));
    await _settle();
    await Future<void>.delayed(const Duration(milliseconds: 2200)); // отложенная запись
    expect(store.files.containsKey(StreamStatsController.fileName), isTrue);
    c.dispose();

    c = await _container(store);
    expect(c.read(streamStatsProvider).live.giftUnits, 5);
    c.read(eventBusProvider)
      ..publish(RoomInfoEvent(uniqueId: 'dirron', roomId: 'R1', followers: 100))
      ..publish(_gift('Роза', 5, combo: 'y', key: 'group:alex:5655:9'));
    await _settle();
    expect(c.read(streamStatsProvider).live.giftUnits, 5, reason: 'повтор серии после переподключения');
    // Новый эфир — с нуля.
    c.read(eventBusProvider).publish(RoomInfoEvent(uniqueId: 'dirron', roomId: 'R2'));
    await _settle();
    expect(c.read(streamStatsProvider).live.giftUnits, 0);
    c.dispose();
  });

  test('все 13 оверлеев строятся пустыми и с тестовыми данными; причины нехватки данных', () async {
    final c = await _container();
    for (final kind in OverlayKind.values) {
      expect(_model(c, kind)['title'], isNotEmpty, reason: kind.slug);
    }
    final inputs = c.read(overlayInputsProvider);
    expect(overlayDataIssue(OverlayKind.topLikers, inputs), contains('лайков'));
    expect(overlayDataIssue(OverlayKind.streamTime, inputs), contains('вручную'));
    expect(overlayDataIssue(OverlayKind.parkourProgress, inputs), isNotNull);

    await c.read(overlaySettingsProvider.notifier).setTestMode(true);
    for (final kind in OverlayKind.values) {
      c.read(streamStatsProvider.notifier).seedTest(kind);
      final m = _model(c, kind);
      expect(m['test'], isTrue, reason: kind.slug);
      expect(jsonEncode(m), isNotEmpty);
    }
    expect(_model(c, OverlayKind.parkourProgress)['main'], 'Комната 37 / 100');
    expect(_model(c, OverlayKind.roomAttempts)['sub'], 'Попытка 3');
    expect(_model(c, OverlayKind.viewerAction)['main'], 'Mira отправляет Dirron на уровень 1');

    await c.read(overlaySettingsProvider.notifier).update(OverlayKind.streamTime, {'manualStart': '19:30'});
    expect(_model(c, OverlayKind.streamTime)['startedAtMs'], isNotNull);
    await c.read(overlaySettingsProvider.notifier).update(OverlayKind.challenge, {'status': 'done'});
    expect(_model(c, OverlayKind.challenge)['sub'], 'Выполнено!');
    c.dispose();
  });

  test('сервер оверлеев: постоянная ссылка, JSON без кэша, 404 для неизвестного', () async {
    final c = await _container();
    final server = c.read(overlayServerProvider.notifier);
    await server.start(
        port: 0, checkHost: false, template: '<html><body style="background:transparent">{{SLUG}} {{TITLE}}</body></html>');
    final state = c.read(overlayServerProvider);
    expect(state.running, isTrue);
    // TikTok LIVE Studio не принимает localhost и IP — ссылка через имя с точкой.
    expect(state.linkFor(OverlayKind.goal), 'http://localtest.me:${state.port}/overlay/goal');
    expect(state.localLinkFor(OverlayKind.goal), 'http://127.0.0.1:${state.port}/overlay/goal');

    // flutter_test подменяет HttpClient заглушкой, которая всегда отвечает 400.
    // Здесь нужен настоящий запрос к локальному серверу.
    final overrides = HttpOverrides.current;
    HttpOverrides.global = null;
    addTearDown(() => HttpOverrides.global = overrides);
    final client = HttpClient();
    Future<(int, String, HttpHeaders)> get(String path) async {
      final req = await client.getUrl(Uri.parse('http://127.0.0.1:${state.port}$path'));
      final res = await req.close();
      return (res.statusCode, await res.transform(utf8.decoder).join(), res.headers);
    }

    final page = await get('/overlay/gift-battle');
    expect(page.$1, 200);
    expect(page.$2, contains('gift-battle Гифт-батл'));
    expect(page.$2, contains('transparent'));
    final api = await get('/api/overlay/goal');
    expect(api.$1, 200);
    expect(api.$3.value('cache-control'), 'no-store');
    expect((jsonDecode(api.$2) as Map)['kind'], 'goal');
    for (final kind in OverlayKind.values) {
      expect((await get('/api/overlay/${kind.slug}')).$1, 200, reason: kind.slug);
    }
    expect((await get('/overlay/nope')).$1, 404);
    client.close(force: true);
    await server.stop();
    c.dispose();
  });

  for (final size in const [Size(1920, 1080), Size(1024, 700)]) {
    testWidgets('${size.width.toInt()}×${size.height.toInt()}: вкладка «Оверлеи» — 13 виджетов с кнопками',
        (tester) async {
      final container = await pumpDirronlive(tester, MemoryJsonStore(), size: size);
      await openSection(tester, 'overlays');
      for (final kind in OverlayKind.values) {
        expect(find.byKey(Key('overlay-${kind.slug}')), findsOneWidget, reason: kind.slug);
        expect(find.byKey(Key('overlay-config-${kind.slug}')), findsOneWidget);
        expect(find.byKey(Key('overlay-test-${kind.slug}')), findsOneWidget);
        expect(find.byKey(Key('overlay-copy-${kind.slug}')), findsOneWidget);
      }
      // Тестовая серия ×5 → тестовый режим, цель и комбо обновились.
      await tester.ensureVisible(find.byKey(const Key('overlay-test-series')));
      await tester.tap(find.byKey(const Key('overlay-test-series')));
      await tester.pumpAndSettle();
      expectNoFlutterError(tester, 'тестовая серия');
      expect(container.read(overlaySettingsProvider).testMode, isTrue);
      expect(container.read(streamStatsProvider).test.giftUnits, 5);

      // «Настроить» цель открывается и закрывается.
      await tester.ensureVisible(find.byKey(const Key('overlay-config-goal')));
      await tester.tap(find.byKey(const Key('overlay-config-goal')));
      await tester.pumpAndSettle();
      expectNoFlutterError(tester, 'настройка цели');
      expect(find.byKey(const Key('overlay-config-dialog-goal')), findsOneWidget);
      await tester.tap(find.byKey(const Key('cfg-goal-specificGift')));
      await tester.pumpAndSettle();
      await tester.ensureVisible(find.byKey(const Key('cfg-close')));
      await tester.tap(find.byKey(const Key('cfg-close')));
      await tester.pumpAndSettle();

      // Холст 1080×1920 с целью и батлом.
      await tester.ensureVisible(find.byKey(const Key('overlay-canvas')));
      await tester.tap(find.byKey(const Key('overlay-canvas')));
      await tester.pumpAndSettle();
      expectNoFlutterError(tester, 'холст 1080×1920');
      expect(find.byKey(const Key('overlay-canvas-dialog')), findsOneWidget);
      await tester.tapAt(const Offset(5, 5));
      await tester.pumpAndSettle();

      expect(container.read(overlaySettingsProvider).of(OverlayKind.goal)['type'], 'specificGift');
      await closeDirronlive(tester, container);
    });
  }

  test('внешний вид оверлея: по умолчанию с рамкой; рамка, размер и цвет меняются и ограничены', () async {
    final c = await _container();
    Map<String, Object?> style() => (_model(c, OverlayKind.topLikers)['style']! as Map).cast<String, Object?>();
    expect(style(), {
      'frame': 'card',
      'scale': 100,
      'accent': '#A78BFA',
      'bg': 86,
      'showTitle': true,
      'align': 'left',
    });
    final settings = c.read(overlaySettingsProvider.notifier);
    await settings.update(OverlayKind.topLikers,
        {'frame': 'none', 'scale': 999, 'accent': '#123456', 'bg': -5, 'showTitle': false, 'align': 'center'});
    expect(style(), {
      'frame': 'none',
      'scale': 200,
      'accent': '#A78BFA',
      'bg': 0,
      'showTitle': false,
      'align': 'center',
    }, reason: 'размер не больше 200%, чужой цвет не принимается');
    await settings.update(OverlayKind.topLikers, {'frame': 'plain', 'scale': 30, 'accent': '#A3FF47'});
    expect(style()['frame'], 'plain');
    expect(style()['scale'], 50);
    expect(style()['accent'], '#A3FF47');
    // У другого оверлея свой вид.
    expect((_model(c, OverlayKind.goal)['style']! as Map)['frame'], 'card');
    c.dispose();
  });
}
