String _two(int value) => value.toString().padLeft(2, '0');

/// 00:31:05
String formatTime(DateTime time) =>
    '${_two(time.hour)}:${_two(time.minute)}:${_two(time.second)}';

/// 23.11.2026
String formatDate(DateTime time) =>
    '${_two(time.day)}.${_two(time.month)}.${time.year}';

/// 23.11.2026 00:31:05
String formatDateTime(DateTime time) => '${formatDate(time)} ${formatTime(time)}';
