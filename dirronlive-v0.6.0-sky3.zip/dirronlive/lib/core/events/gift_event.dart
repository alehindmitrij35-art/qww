import 'dart:math';

import 'app_event.dart';
import 'delivery_status.dart';
import 'event_source.dart';

/// Подарок от зрителя.
///
/// Комбо (зритель много раз подряд жмёт один подарок, как в TikTok LIVE)
/// приходит в шину серией событий с общим [comboId] и растущим
/// накопленным [count]; последнее событие серии — с `comboActive: false`.
/// В журнале вся серия хранится одной записью, у которой растёт [count].
class GiftEvent extends AppEvent {
  const GiftEvent({
    required this.id,
    required this.createdAt,
    required this.source,
    required this.viewerName,
    required this.giftName,
    required this.count,
    this.delivery = DeliveryStatus.logOnly,
    this.comboId,
    this.comboActive = false,
    this.deliveredCount = 0,
    this.giftId,
    this.actionTitle,
    this.actionResult,
    this.actionState = ActionState.none,
    this.unknownGift = false,
    this.viewerId,
    this.giftImage,
    this.diamonds = 0,
    this.sourceKey,
    this.viewerAvatar,
  });

  /// Аватарка зрителя от TikTok (https), если пришла.
  final String? viewerAvatar;

  /// ID зрителя в TikTok (для рейтингов); у тестовых — ник.
  final String? viewerId;

  /// Картинка подарка от TikTok, если пришла.
  final String? giftImage;

  /// Стоимость одной штуки в монетах TikTok (0 — неизвестна).
  final int diamonds;

  /// Постоянный ключ события TikTok (сообщение или серия): по нему
  /// статистика не считает подарок второй раз после переподключения.
  final String? sourceKey;

  @override
  final String id;

  @override
  final DateTime createdAt;

  final EventSource source;
  final String viewerName;
  final String giftName;
  final int count;

  /// Статус доставки в Minecraft.
  final DeliveryStatus delivery;

  /// Общий ID серии комбо или `null` для одиночного подарка.
  final String? comboId;

  /// Комбо ещё продолжается (зритель продолжает жать подарок).
  final bool comboActive;

  /// Сколько подарков из [count] показано в игре и подтверждено модом.
  final int deliveredCount;

  /// ID подарка в TikTok (`5655` для «Розы»); у тестовых — `null`.
  final String? giftId;

  /// Действие паркура, назначенное подарку: «Комната назад».
  final String? actionTitle;

  /// Что произошло в игре: «Комната 12 → 11» или причина, почему нет.
  final String? actionResult;

  final ActionState actionState;

  /// Подарка нет в сохранённом каталоге эфира — стоит обновить каталог.
  final bool unknownGift;

  bool get isCombo => comboId != null;

  /// Строка для истории и ленты: «Тест · Комната 12 → 11».
  String? get actionText => switch (actionState) {
        ActionState.none =>
          unknownGift ? 'Подарка нет в каталоге — обновите каталог' : null,
        ActionState.pending =>
          '«${actionTitle ?? 'Действие'}» → ${actionResult ?? 'отправляется'}',
        ActionState.done => source == EventSource.test
            ? 'Тест · ${actionResult ?? actionTitle ?? ''}'
            : (actionResult ?? actionTitle ?? ''),
        ActionState.failed || ActionState.skipped =>
          '«${actionTitle ?? 'Действие'}»: ${actionResult ?? 'не выполнено'}',
      };

  /// Строка для ленты: «Тестовый зритель отправил подарок „Роза“ ×1».
  String get feedText => '$viewerName отправил подарок „$giftName“ ×$count';

  /// Название и количество одной строкой: «Роза ×5».
  String get giftText => '$giftName ×$count';

  /// Подпись статуса доставки; для частичной доставки — «Доставлено 10 из 15».
  String get deliveryLabel => delivery == DeliveryStatus.partial
      ? 'Доставлено $deliveredCount из $count'
      : delivery.label;

  GiftEvent copyWith({
    DeliveryStatus? delivery,
    int? count,
    bool? comboActive,
    int? deliveredCount,
    String? actionTitle,
    String? actionResult,
    ActionState? actionState,
    bool? unknownGift,
  }) =>
      GiftEvent(
        id: id,
        createdAt: createdAt,
        source: source,
        viewerName: viewerName,
        giftName: giftName,
        count: count ?? this.count,
        delivery: delivery ?? this.delivery,
        comboId: comboId,
        comboActive: comboActive ?? this.comboActive,
        deliveredCount: deliveredCount ?? this.deliveredCount,
        giftId: giftId,
        actionTitle: actionTitle ?? this.actionTitle,
        actionResult: actionResult ?? this.actionResult,
        actionState: actionState ?? this.actionState,
        unknownGift: unknownGift ?? this.unknownGift,
        viewerId: viewerId,
        giftImage: giftImage,
        diamonds: diamonds,
        sourceKey: sourceKey,
        viewerAvatar: viewerAvatar,
      );

  Map<String, Object?> toJson() => {
        'id': id,
        'createdAt': createdAt.toUtc().toIso8601String(),
        'source': source.id,
        'viewerName': viewerName,
        'giftName': giftName,
        'count': count,
        'delivery': delivery.id,
        'deliveredCount': deliveredCount,
        if (comboId != null) 'comboId': comboId,
        if (comboId != null) 'comboActive': comboActive,
        if (giftId != null) 'giftId': giftId,
        if (actionTitle != null) 'actionTitle': actionTitle,
        if (actionResult != null) 'actionResult': actionResult,
        if (actionState != ActionState.none) 'actionState': actionState.id,
        if (unknownGift) 'unknownGift': true,
        if (viewerId != null) 'viewerId': viewerId,
        if (giftImage != null) 'giftImage': giftImage,
        if (diamonds > 0) 'diamonds': diamonds,
        if (sourceKey != null) 'sourceKey': sourceKey,
        if (viewerAvatar != null) 'viewerAvatar': viewerAvatar,
      };

  /// Разбирает запись из файла истории.
  /// Бросает [FormatException], если запись повреждена.
  /// Записи первой версии без поля `delivery` получают «Только в журнале».
  factory GiftEvent.fromJson(Object? json) {
    if (json is! Map) {
      throw const FormatException('Запись события не является объектом');
    }
    final id = json['id'];
    final createdAt = json['createdAt'];
    final source = EventSource.fromId(json['source']);
    final viewerName = json['viewerName'];
    final giftName = json['giftName'];
    final count = json['count'];

    if (id is! String || id.isEmpty) {
      throw const FormatException('У события нет id');
    }
    if (createdAt is! String) {
      throw const FormatException('У события нет времени создания');
    }
    final parsedTime = DateTime.tryParse(createdAt);
    if (parsedTime == null) {
      throw FormatException('Неверное время события: $createdAt');
    }
    if (source == null) {
      throw FormatException('Неизвестный источник события: ${json['source']}');
    }
    if (viewerName is! String || giftName is! String) {
      throw const FormatException('У события нет имени зрителя или подарка');
    }
    if (count is! int || count < 1) {
      throw const FormatException('Неверное количество подарков');
    }

    final delivery = DeliveryStatus.fromId(json['delivery']);
    final comboId = json['comboId'];
    final storedDelivered = json['deliveredCount'];
    // В записях 0.2.0 нет deliveredCount: «Доставлено» значит доставлено всё.
    final int deliveredCount;
    if (storedDelivered is int) {
      deliveredCount = storedDelivered < 0
          ? 0
          : (storedDelivered > count ? count : storedDelivered);
    } else {
      deliveredCount = delivery == DeliveryStatus.delivered ? count : 0;
    }

    return GiftEvent(
      id: id,
      createdAt: parsedTime.toLocal(),
      source: source,
      viewerName: viewerName,
      giftName: giftName,
      count: count,
      delivery: delivery,
      comboId: comboId is String && comboId.isNotEmpty ? comboId : null,
      comboActive: json['comboActive'] == true,
      deliveredCount: deliveredCount,
      giftId: _optionalString(json['giftId']),
      actionTitle: _optionalString(json['actionTitle']),
      actionResult: _optionalString(json['actionResult']),
      actionState: ActionState.fromId(json['actionState']),
      unknownGift: json['unknownGift'] == true,
      viewerId: _optionalString(json['viewerId']),
      giftImage: _optionalString(json['giftImage']),
      diamonds: json['diamonds'] is num ? (json['diamonds']! as num).toInt() : 0,
      sourceKey: _optionalString(json['sourceKey']),
      viewerAvatar: _optionalString(json['viewerAvatar']),
    );
  }

  static String? _optionalString(Object? value) =>
      value is String && value.isNotEmpty ? value : null;

  @override
  bool operator ==(Object other) =>
      other is GiftEvent &&
      other.id == id &&
      other.createdAt == createdAt &&
      other.source == source &&
      other.viewerName == viewerName &&
      other.giftName == giftName &&
      other.count == count &&
      other.delivery == delivery &&
      other.comboId == comboId &&
      other.comboActive == comboActive &&
      other.deliveredCount == deliveredCount &&
      other.giftId == giftId &&
      other.actionTitle == actionTitle &&
      other.actionResult == actionResult &&
      other.actionState == actionState &&
      other.unknownGift == unknownGift &&
      other.viewerId == viewerId &&
      other.giftImage == giftImage &&
      other.diamonds == diamonds &&
      other.sourceKey == sourceKey &&
      other.viewerAvatar == viewerAvatar;

  @override
  int get hashCode => Object.hash(id, createdAt, source, viewerName, giftName,
      count, delivery, comboId, comboActive, deliveredCount, giftId,
      actionTitle, actionResult, actionState, unknownGift, viewerId, giftImage,
      diamonds, sourceKey, viewerAvatar);

  @override
  String toString() => 'GiftEvent($id, ${source.id}, $viewerName, '
      '$giftName ×$count, ${delivery.id} $deliveredCount/$count, '
      'combo=${comboId ?? '-'}${comboActive ? ' active' : ''}, $createdAt)';
}

/// Что стало с действием паркура, назначенным подарку.
enum ActionState {
  none('none'),
  pending('pending'),
  done('done'),
  failed('failed'),
  skipped('skipped');

  const ActionState(this.id);

  final String id;

  static ActionState fromId(Object? id) {
    for (final state in values) {
      if (state.id == id) return state;
    }
    return none;
  }
}

final Random _random = Random.secure();

/// Случайный UUID версии 4, например `3f2b8c1e-9d4a-4c7b-8e21-5a6f0b9c2d13`.
String generateEventId() {
  final bytes = List<int>.generate(16, (_) => _random.nextInt(256));
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  final hex = bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
  return '${hex.substring(0, 8)}-${hex.substring(8, 12)}-'
      '${hex.substring(12, 16)}-${hex.substring(16, 20)}-${hex.substring(20)}';
}
