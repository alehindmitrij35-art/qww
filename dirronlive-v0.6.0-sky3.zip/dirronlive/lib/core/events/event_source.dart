/// Откуда пришло событие.
enum EventSource {
  /// Кнопка «Тестовый подарок».
  test('test', 'Тест'),

  /// Реальный эфир TikTok LIVE (через будущий TikTok Connector).
  tiktok('tiktok', 'TikTok LIVE');

  const EventSource(this.id, this.label);

  /// Значение, которое хранится в файле истории.
  final String id;

  /// Подпись в интерфейсе.
  final String label;

  static EventSource? fromId(Object? value) {
    for (final source in values) {
      if (source.id == value) return source;
    }
    return null;
  }
}
