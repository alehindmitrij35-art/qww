import 'package:flutter/material.dart';

import '../../core/events/gift_event.dart';
import '../../core/format.dart';
import '../theme/app_colors.dart';
import 'common.dart';

/// Запись в ленте экрана «Эфир».
///
/// Ник зрителя — жирным, подарок и количество — одной строкой («Роза ×5»),
/// ниже время, источник и серия. Справа статус доставки: лаймовая галочка,
/// когда Minecraft подтвердил. Новая запись на 0,7 с подсвечивается
/// розово-фиолетовой полосой слева — так видно «пришло из TikTok» и,
/// отдельно, «появилось в игре».
class EventTile extends StatelessWidget {
  const EventTile({super.key, required this.event, this.highlighted = false});

  final GiftEvent event;

  /// Подсветить левый край (новая запись).
  final bool highlighted;

  @override
  Widget build(BuildContext context) {
    final meta = [
      formatTime(event.createdAt),
      event.source.label,
      if (event.isCombo && event.comboActive) 'комбо идёт…',
      if (event.isCombo && !event.comboActive && event.count > 1) 'комбо',
    ].join(' · ');

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          AnimatedOpacity(
            opacity: highlighted ? 1 : 0,
            duration: const Duration(milliseconds: 160),
            child: Container(
              key: highlighted ? ValueKey('highlight-${event.id}') : null,
              width: 4,
              height: 52,
              decoration: BoxDecoration(
                gradient: AppColors.brandGradientVertical,
                borderRadius: BorderRadius.circular(2),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.accentAlt.withAlpha(120),
                    blurRadius: 10,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 10),
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: AppColors.accentAlt.withAlpha(36),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.redeem_rounded,
              color: AppColors.accentAlt,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  event.viewerName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                    color: AppColors.text,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  event.giftText,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textMuted,
                  ),
                ),
                if (event.actionText != null) ...[
                  const SizedBox(height: 2),
                  Text(
                    event.actionText!,
                    key: ValueKey('feed-action-${event.id}'),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: switch (event.actionState) {
                        ActionState.done => AppColors.success,
                        ActionState.pending => AppColors.warning,
                        ActionState.failed => AppColors.danger,
                        _ => AppColors.textMuted,
                      },
                    ),
                  ),
                ],
                const SizedBox(height: 2),
                Text(
                  meta,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 12,
                    color: AppColors.textFaint,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 210),
            child: DeliveryChip(
              key: ValueKey('delivery-${event.id}'),
              status: event.delivery,
              label: event.deliveryLabel,
            ),
          ),
        ],
      ),
    );
  }
}
