import 'dart:async';
import 'dart:convert';
import 'dart:io';

/// Сессия коннектора: одно подключение к эфиру. Поток [messages] — строки
/// JSON от коннектора (см. tiktok_connector/connector.mjs); он закрывается,
/// когда процесс коннектора завершился.
abstract interface class TikTokSession {
  Stream<Map<String, Object?>> get messages;

  /// Остановить подключение (Dirronlive сам завершает процесс).
  Future<void> stop();

  /// Попросить коннектор прислать каталог подарков этого эфира
  /// (`{"type":"gifts"}` или `{"type":"giftsError"}`). `false` — не отправлено.
  bool requestGifts();
}

abstract interface class TikTokConnectorBackend {
  TikTokSession start({required String uniqueId, String? apiKey});
}

/// Где лежат Node.js и коннектор.
class ConnectorLocation {
  const ConnectorLocation({
    required this.node,
    required this.script,
    required this.workingDirectory,
  });

  final String node;
  final String script;
  final String workingDirectory;

  /// 1) рядом с программой: `<папка dirronlive.exe>\tiktok\node.exe` и
  ///    `connector.mjs` — так устанавливает установщик;
  /// 2) при разработке (`flutter run`): `tiktok_connector\connector.mjs` в
  ///    папке проекта и `node` из PATH.
  static ConnectorLocation? resolve() {
    final sep = Platform.pathSeparator;
    final exeDir = File(Platform.resolvedExecutable).parent.path;
    final bundled = '$exeDir${sep}tiktok';
    final bundledNode =
        '$bundled$sep${Platform.isWindows ? 'node.exe' : 'node'}';
    final bundledScript = '$bundled${sep}connector.mjs';
    if (File(bundledNode).existsSync() && File(bundledScript).existsSync()) {
      return ConnectorLocation(
        node: bundledNode,
        script: bundledScript,
        workingDirectory: bundled,
      );
    }
    final dev = '${Directory.current.path}${sep}tiktok_connector';
    final devScript = '$dev${sep}connector.mjs';
    if (File(devScript).existsSync()) {
      return ConnectorLocation(
        node: 'node',
        script: devScript,
        workingDirectory: dev,
      );
    }
    return null;
  }
}

/// Запускает коннектор отдельным процессом Node.js и сам его останавливает.
class NodeConnectorBackend implements TikTokConnectorBackend {
  NodeConnectorBackend({this.location, this.environment});

  /// Если не задано — ищется через [ConnectorLocation.resolve].
  final ConnectorLocation? location;

  /// Дополнительные переменные окружения (для тестов).
  final Map<String, String>? environment;

  @override
  TikTokSession start({required String uniqueId, String? apiKey}) {
    final session = _NodeSession();
    final where = location ?? ConnectorLocation.resolve();
    if (where == null) {
      session.fail('Коннектор TikTok не найден рядом с программой. '
          'Переустановите Dirronlive.');
    } else {
      unawaited(session.run(where, [
        where.script,
        '--user',
        uniqueId,
        if (apiKey != null && apiKey.isNotEmpty) ...['--key', apiKey],
      ], environment));
    }
    return session;
  }
}

class _NodeSession implements TikTokSession {
  final StreamController<Map<String, Object?>> _controller =
      StreamController<Map<String, Object?>>();
  Process? _process;
  bool _stopRequested = false;

  @override
  Stream<Map<String, Object?>> get messages => _controller.stream;

  void fail(String message) {
    _controller.add({
      'type': 'status',
      'status': 'error',
      'kind': 'service',
      'message': message,
    });
    unawaited(_controller.close());
  }

  Future<void> run(
    ConnectorLocation where,
    List<String> arguments,
    Map<String, String>? environment,
  ) async {
    final Process process;
    try {
      process = await Process.start(
        where.node,
        arguments,
        workingDirectory: where.workingDirectory,
        environment: environment,
      );
    } on ProcessException catch (e) {
      fail('Не удалось запустить коннектор TikTok: ${e.message}');
      return;
    }
    _process = process;
    if (_stopRequested) {
      await stop();
    }

    final stdoutDone = process.stdout
        .transform(utf8.decoder)
        .transform(const LineSplitter())
        .listen(_onLine)
        .asFuture<void>();
    final stderrDone = process.stderr
        .transform(utf8.decoder)
        .transform(const LineSplitter())
        .listen((line) {
      if (!_controller.isClosed && line.trim().isNotEmpty) {
        _controller.add({'type': 'log', 'level': 'stderr', 'message': line});
      }
    }).asFuture<void>();

    final code = await process.exitCode;
    await Future.wait([stdoutDone, stderrDone]).catchError((Object _) => <void>[]);
    if (!_controller.isClosed) {
      _controller.add({'type': 'exit', 'code': code});
      await _controller.close();
    }
  }

  void _onLine(String line) {
    if (_controller.isClosed) return;
    final text = line.trim();
    if (!text.startsWith('{')) return;
    try {
      final decoded = jsonDecode(text);
      if (decoded is Map) _controller.add(decoded.cast<String, Object?>());
    } on FormatException {
      // Не JSON — пропускаем.
    }
  }

  @override
  bool requestGifts() {
    final process = _process;
    if (process == null || _stopRequested) return false;
    try {
      process.stdin.writeln('gifts');
      return true;
    } catch (_) {
      return false;
    }
  }

  @override
  Future<void> stop() async {
    _stopRequested = true;
    final process = _process;
    if (process == null) return;
    try {
      process.stdin.writeln('stop');
      await process.stdin.close();
    } catch (_) {
      // Процесс уже завершился.
    }
    // Если коннектор не вышел сам — завершаем принудительно.
    await process.exitCode.timeout(const Duration(seconds: 3), onTimeout: () {
      process.kill();
      return -1;
    });
  }
}
