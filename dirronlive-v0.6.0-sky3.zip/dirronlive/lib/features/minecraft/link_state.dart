import 'link_protocol.dart';

/// Фактическое состояние связи с модом Dirronlive Bridge.
enum LinkPhase {
  off('Связь выключена'),
  starting('Запуск связи…'),
  waitingForMod('Ожидание мода'),
  modConnected('Мод подключён • открой одиночный мир'),
  worldReady('Мир готов'),
  error('Ошибка связи');

  const LinkPhase(this.label);

  final String label;
}

class MinecraftLinkState {
  const MinecraftLinkState({
    this.phase = LinkPhase.off,
    this.port,
    this.errorTitle,
    this.errorMessage,
    this.modVersion,
    this.minecraftVersion,
    this.parkourActions = false,
    this.actionQueue = false,
    this.parkour = ParkourInfo.none,
    this.skyMode = false,
    this.sky = SkyInfo.none,
  });

  /// Мод умеет «Небесный разлом».
  final bool skyMode;

  /// Трасса и заезд «Небесного разлома» в открытом мире.
  final SkyInfo sky;

  /// Можно управлять полётом прямо сейчас.
  bool get skyReady => worldReady && skyMode && sky.available;

  /// Почему «Небесный разлом» сейчас недоступен (или `null`).
  String? get skyBlocker {
    if (phase == LinkPhase.off) {
      return 'Связь с игрой выключена — включите её в Настройках → Подключения';
    }
    if (!modConnected) return 'Мод Dirronlive Bridge не подключён — запустите Minecraft';
    if (!skyMode) return 'Мод старой версии — установите новый Dirronlive Bridge из набора';
    if (!worldReady) return 'Откройте одиночный мир DirronSky';
    if (sky.map == 'preparing') {
      return sky.problem.isEmpty ? 'Трасса загружается…' : 'Трасса с ошибкой: ${sky.problem}';
    }
    if (!sky.available) return 'В открытом мире нет трассы — откройте мир DirronSky';
    return null;
  }

  /// Мод 2.1+: серии подарков идут очередью, одна штука = одно срабатывание.
  final bool actionQueue;

  final LinkPhase phase;

  /// Мод умеет действия паркура (версия 2.0+).
  final bool parkourActions;

  /// Карта в открытом мире: доступна ли, комната игрока.
  final ParkourInfo parkour;

  /// Можно выполнять действия паркура прямо сейчас.
  bool get parkourReady => worldReady && parkourActions && actionQueue && parkour.available;

  /// Почему действия паркура сейчас не выполнить (или `null`, если можно).
  String? get parkourBlocker {
    if (phase == LinkPhase.off) {
      return 'Связь с игрой выключена — включите её в Настройках → Подключения';
    }
    if (!modConnected) return 'Мод Dirronlive Bridge не подключён — запустите Minecraft';
    if (!parkourActions || !actionQueue) {
      return 'Мод старой версии — установите Dirronlive Bridge 2.2.0';
    }
    if (!worldReady) return 'Откройте одиночный мир DirronParkour';
    if (sky.available) return 'Открыт мир «Небесный разлом» — для паркура откройте мир DirronParkour';
    if (!parkour.available) return 'В открытом мире нет карты — откройте мир DirronParkour';
    return null;
  }

  /// Порт, на котором работает (или пытался запуститься) сервер.
  final int? port;

  /// Короткий заголовок ошибки, например «Порт 8765 занят».
  final String? errorTitle;

  /// Понятное объяснение ошибки и что делать.
  final String? errorMessage;

  /// Версии, которые сообщил мод при подключении.
  final String? modVersion;
  final String? minecraftVersion;

  /// Связь включена пользователем (сервер работает или пытается).
  bool get enabled => phase != LinkPhase.off;

  bool get modConnected =>
      phase == LinkPhase.modConnected || phase == LinkPhase.worldReady;

  bool get worldReady => phase == LinkPhase.worldReady;

  /// Текст статуса — одинаковый на экране «Эфир» и в настройках.
  String get label =>
      phase == LinkPhase.error ? (errorTitle ?? phase.label) : phase.label;

  MinecraftLinkState copyWith({
    LinkPhase? phase,
    String? modVersion,
    String? minecraftVersion,
    bool? parkourActions,
    bool? actionQueue,
    ParkourInfo? parkour,
    bool? skyMode,
    SkyInfo? sky,
  }) =>
      MinecraftLinkState(
        phase: phase ?? this.phase,
        port: port,
        errorTitle: errorTitle,
        errorMessage: errorMessage,
        modVersion: modVersion ?? this.modVersion,
        minecraftVersion: minecraftVersion ?? this.minecraftVersion,
        parkourActions: parkourActions ?? this.parkourActions,
        actionQueue: actionQueue ?? this.actionQueue,
        parkour: parkour ?? this.parkour,
        skyMode: skyMode ?? this.skyMode,
        sky: sky ?? this.sky,
      );
}
