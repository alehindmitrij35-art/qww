import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/events/event_source.dart';
import '../../core/events/gift_event.dart';
import '../parkour/parkour_rules.dart';
import '../../core/events/stream_events.dart';
import '../../core/providers.dart';
import '../../core/storage/json_store.dart';
import '../parkour/gift_catalog.dart';
import '../parkour/parkour_engine.dart';
import 'overlay_kind.dart';
import 'overlay_settings.dart';

/// Лучший подарок или комбо.
class GiftMark {
  const GiftMark({
    required this.viewer,
    required this.giftName,
    this.giftId,
    this.image,
    this.diamonds = 0,
    this.count = 1,
  });

  final String viewer;
  final String giftName;
  final String? giftId;
  final String? image;
  final int diamonds;
  final int count;

  Map<String, Object?> toJson() => {
        'viewer': viewer,
        'giftName': giftName,
        'giftId': giftId,
        'image': image,
        'diamonds': diamonds,
        'count': count,
      };

  static GiftMark? fromJson(Object? j) {
    if (j is! Map) return null;
    final viewer = j['viewer'];
    final gift = j['giftName'];
    if (viewer is! String || gift is! String) return null;
    return GiftMark(
      viewer: viewer,
      giftName: gift,
      giftId: j['giftId'] is String ? j['giftId']! as String : null,
      image: j['image'] is String ? j['image']! as String : null,
      diamonds: j['diamonds'] is num ? (j['diamonds']! as num).toInt() : 0,
      count: j['count'] is num ? (j['count']! as num).toInt() : 1,
    );
  }
}

/// Статистика одного «мира»: реального эфира или тестового режима.
///
/// Все показатели считаются из одной обработанной ленты: серия из пяти
/// роз — пять роз в цель, одно комбо ×5 и пять очков в батле. Прирост
/// серии берётся по постоянному ключу события, поэтому повтор после
/// переподключения не считается второй раз.
class StatsBucket {
  StatsBucket();

  String? roomId;
  DateTime? startedAt;
  int? followersAtStart;
  int newFollowers = 0;
  int totalLikes = 0;
  int giftUnits = 0;
  bool likesSeen = false;
  bool pricesSeen = false;
  final Map<String, int> likesByViewer = {};
  final Map<String, int> coinsByViewer = {};
  final Map<String, String> names = {};
  /// Ключ зрителя → ссылка на аватарку TikTok.
  final Map<String, String> avatars = {};
  final Map<String, int> unitsByGift = {};
  final Map<String, String> giftImages = {};
  GiftMark? bestGift;
  GiftMark? bestCombo;

  /// Ключ события → уже засчитано штук.
  final Map<String, int> counted = {};
  final Set<String> seenKeys = {};

  // Гифт-батл и голосование — счёт текущего раунда.
  int battleLeft = 0;
  int battleRight = 0;
  final Map<String, String> votes = {};
  ViewerActionEvent? lastAction;

  int giftUnitsOf(String key) => unitsByGift[key] ?? 0;

  Map<String, Object?> toJson() => {
        'roomId': roomId,
        'startedAt': startedAt?.toUtc().toIso8601String(),
        'followersAtStart': followersAtStart,
        'newFollowers': newFollowers,
        'totalLikes': totalLikes,
        'giftUnits': giftUnits,
        'likesSeen': likesSeen,
        'pricesSeen': pricesSeen,
        'likesByViewer': likesByViewer,
        'coinsByViewer': coinsByViewer,
        'names': names,
        'avatars': avatars,
        'unitsByGift': unitsByGift,
        'giftImages': giftImages,
        'bestGift': bestGift?.toJson(),
        'bestCombo': bestCombo?.toJson(),
        'counted': counted,
        'seenKeys': seenKeys.toList(),
        'battleLeft': battleLeft,
        'battleRight': battleRight,
        'votes': votes,
      };

  static StatsBucket fromJson(Map<String, Object?> j) {
    final b = StatsBucket();
    b.roomId = j['roomId'] is String ? j['roomId']! as String : null;
    b.startedAt = j['startedAt'] is String ? DateTime.tryParse(j['startedAt']! as String)?.toLocal() : null;
    b.followersAtStart = j['followersAtStart'] is num ? (j['followersAtStart']! as num).toInt() : null;
    int n(String k) => j[k] is num ? (j[k]! as num).toInt() : 0;
    b.newFollowers = n('newFollowers');
    b.totalLikes = n('totalLikes');
    b.giftUnits = n('giftUnits');
    b.likesSeen = j['likesSeen'] == true;
    b.pricesSeen = j['pricesSeen'] == true;
    void intMap(String k, Map<String, int> into) {
      final m = j[k];
      if (m is! Map) return;
      m.forEach((key, v) {
        if (key is String && v is num) into[key] = v.toInt();
      });
    }

    void strMap(String k, Map<String, String> into) {
      final m = j[k];
      if (m is! Map) return;
      m.forEach((key, v) {
        if (key is String && v is String) into[key] = v;
      });
    }

    intMap('likesByViewer', b.likesByViewer);
    intMap('coinsByViewer', b.coinsByViewer);
    strMap('names', b.names);
    strMap('avatars', b.avatars);
    intMap('unitsByGift', b.unitsByGift);
    strMap('giftImages', b.giftImages);
    intMap('counted', b.counted);
    strMap('votes', b.votes);
    final keys = j['seenKeys'];
    if (keys is List) b.seenKeys.addAll(keys.whereType<String>());
    b.bestGift = GiftMark.fromJson(j['bestGift']);
    b.bestCombo = GiftMark.fromJson(j['bestCombo']);
    b.battleLeft = n('battleLeft');
    b.battleRight = n('battleRight');
    return b;
  }
}

class StatsState {
  const StatsState(this.live, this.test, this.version);

  final StatsBucket live;
  final StatsBucket test;

  /// Растёт при каждом изменении — оверлеи и экран перерисовываются.
  final int version;

  StatsBucket bucket(bool testMode) => testMode ? test : live;
}

final initialLiveStatsProvider = Provider<StatsBucket?>((ref) => null);

final streamStatsProvider = NotifierProvider<StreamStatsController, StatsState>(StreamStatsController.new);

class StreamStatsController extends Notifier<StatsState> {
  static const fileName = 'stream_stats.json';

  final List<StreamSubscription<Object?>> _subs = [];
  Timer? _saveTimer;
  int _version = 0;

  @override
  StatsState build() {
    final bus = ref.read(eventBusProvider);
    _subs
      ..add(bus.on<GiftEvent>().listen(_onGift))
      ..add(bus.on<LikeEvent>().listen(_onLike))
      ..add(bus.on<FollowEvent>().listen(_onFollow))
      ..add(bus.on<ChatEvent>().listen(_onChat))
      ..add(bus.on<RoomInfoEvent>().listen(_onRoom))
      ..add(bus.on<ViewerActionEvent>().listen(_onAction));
    ref.onDispose(() {
      for (final s in _subs) {
        unawaited(s.cancel());
      }
      _saveTimer?.cancel();
    });
    return StatsState(ref.read(initialLiveStatsProvider) ?? StatsBucket(), StatsBucket(), 0);
  }

  StatsBucket _bucketFor(EventSource source) => source == EventSource.test ? state.test : state.live;

  void _changed({bool live = true}) {
    state = StatsState(state.live, state.test, ++_version);
    if (!live) return;
    _saveTimer?.cancel();
    _saveTimer = Timer(const Duration(seconds: 2), () {
      unawaited(ref.read(jsonStoreProvider).write(fileName, state.live.toJson()).catchError((_) {}));
    });
  }

  OverlaySettings get _settings => ref.read(overlaySettingsProvider);

  void _onGift(GiftEvent e) {
    // «Лайки» и «Подписка» для карточек действий — не подарки.
    if (isSocialTrigger(e.giftId)) return;
    final b = _bucketFor(e.source);
    final key = e.sourceKey ?? e.comboId ?? e.id;
    final before = b.counted[key] ?? 0;
    final delta = e.count - before;
    if (delta <= 0) return; // повтор или запоздавший шаг
    b.counted[key] = e.count;
    if (b.counted.length > 20000) b.counted.remove(b.counted.keys.first);
    final viewer = e.viewerId ?? e.viewerName;
    b.names[viewer] = e.viewerName;
    _avatar(b, viewer, e.viewerAvatar);
    b.giftUnits += delta;
    final giftKey = e.giftId ?? e.giftName;
    b.unitsByGift[giftKey] = b.giftUnitsOf(giftKey) + delta;
    if (e.giftId != null) b.unitsByGift[e.giftName] = b.giftUnitsOf(e.giftName) + delta;
    final known = e.giftId == null ? null : ref.read(giftCatalogProvider).catalog.byId(e.giftId!);
    final image = e.giftImage ?? known?.imageUrl;
    final price = e.diamonds > 0 ? e.diamonds : (known?.diamonds ?? 0);
    if (image != null) b.giftImages[giftKey] = image;
    if (price > 0) {
      b.pricesSeen = true;
      b.coinsByViewer[viewer] = (b.coinsByViewer[viewer] ?? 0) + delta * price;
      if (b.bestGift == null || price > b.bestGift!.diamonds) {
        b.bestGift = GiftMark(
            viewer: e.viewerName, giftName: e.giftName, giftId: e.giftId, image: image, diamonds: price);
      }
    } else if (b.bestGift == null && e.source == EventSource.test) {
      b.bestGift = GiftMark(viewer: e.viewerName, giftName: e.giftName, giftId: e.giftId, image: image);
    }
    if (b.bestCombo == null || e.count > b.bestCombo!.count) {
      b.bestCombo = GiftMark(
          viewer: e.viewerName, giftName: e.giftName, giftId: e.giftId, image: image, count: e.count);
    }
    // Гифт-батл: одно очко за каждую штуку подарка стороны.
    final s = _settings;
    if (s.get(OverlayKind.giftBattle, 'running', false)) {
      bool isSide(String side) {
        final id = s.get<String?>(OverlayKind.giftBattle, '${side}GiftId', null);
        final name = s.get<String>(OverlayKind.giftBattle, '${side}Gift', '');
        if (id != null && e.giftId != null) return id == e.giftId;
        return name.isNotEmpty && name.toLowerCase() == e.giftName.toLowerCase();
      }

      if (isSide('left')) b.battleLeft += delta;
      if (isSide('right')) b.battleRight += delta;
    }
    _changed(live: e.source != EventSource.test);
  }

  /// Запомнить аватарку зрителя (новая ссылка заменяет старую: у TikTok они со сроком).
  static void _avatar(StatsBucket b, String viewer, String? url) {
    if (url != null && url.startsWith('http')) b.avatars[viewer] = url;
  }

  void _onLike(LikeEvent e) {
    final b = _bucketFor(e.source);
    final key = e.sourceKey;
    if (key != null && !b.seenKeys.add('like:$key')) return;
    b.likesSeen = true;
    b.names[e.viewerId] = e.viewerName;
    _avatar(b, e.viewerId, e.viewerAvatar);
    b.likesByViewer[e.viewerId] = (b.likesByViewer[e.viewerId] ?? 0) + e.likes;
    b.totalLikes = e.totalLikes ?? b.totalLikes + e.likes;
    _changed(live: e.source != EventSource.test);
  }

  void _onFollow(FollowEvent e) {
    final b = _bucketFor(e.source);
    if (!b.seenKeys.add('follow:${e.viewerId}')) return; // один зритель — одна подписка за эфир
    b.newFollowers++;
    b.names[e.viewerId] = e.viewerName;
    _avatar(b, e.viewerId, e.viewerAvatar);
    _changed(live: e.source != EventSource.test);
  }

  void _onChat(ChatEvent e) {
    _avatar(_bucketFor(e.source), e.viewerId, e.viewerAvatar);
    final s = _settings;
    if (!s.get(OverlayKind.chatVote, 'running', false)) return;
    final text = e.text.trim();
    if (text != '1' && text != '2') return;
    // Последний голос зрителя заменяет предыдущий.
    _vote(_bucketFor(e.source), e.viewerId, e.viewerName, text);
    _changed(live: e.source != EventSource.test);
  }

  void _onRoom(RoomInfoEvent e) {
    final b = state.live;
    if (e.roomId != null && b.roomId != null && e.roomId != b.roomId) {
      // Новый эфир — статистика с нуля.
      final fresh = StatsBucket()..roomId = e.roomId;
      fresh.startedAt = e.startedAt;
      fresh.followersAtStart = e.followers;
      state = StatsState(fresh, state.test, ++_version);
      _changed();
      return;
    }
    b.roomId ??= e.roomId;
    b.startedAt ??= e.startedAt;
    b.followersAtStart ??= e.followers;
    _changed();
  }

  void _onAction(ViewerActionEvent e) {
    (e.test ? state.test : state.live).lastAction = e;
    _changed(live: !e.test);
  }

  // ------------------------------------------------- ручное управление

  void startBattle({required bool test}) {
    final b = test ? state.test : state.live;
    b.battleLeft = 0;
    b.battleRight = 0;
    _changed(live: !test);
  }

  void startVote({required bool test}) {
    (test ? state.test : state.live).votes.clear();
    _changed(live: !test);
  }

  /// Очистить тестовые данные.
  void resetTest() {
    state = StatsState(state.live, StatsBucket(), ++_version);
  }

  /// Новый эфир вручную: обнулить реальную статистику.
  void resetLive() {
    state = StatsState(StatsBucket(), state.test, ++_version);
    _changed();
  }

  /// Тестовые данные для предпросмотра оверлея: сразу в тестовую
  /// статистику, мимо истории и правил паркура.
  void seedTest(OverlayKind kind) {
    const viewers = [('mira', 'Mira'), ('alex', 'Alex'), ('kot', 'Котик'), ('neo', 'Neo'), ('sun', 'Солнце')];
    switch (kind) {
      case OverlayKind.topLikers:
        for (var i = 0; i < viewers.length; i++) {
          _onLike(LikeEvent(
              viewerId: viewers[i].$1, viewerName: viewers[i].$2, likes: 120 - i * 21, source: EventSource.test));
        }
      case OverlayKind.chatVote:
        for (var i = 0; i < viewers.length; i++) {
          _vote(state.test, viewers[i].$1, viewers[i].$2, i.isEven ? '1' : '2');
        }
        _changed(live: false);
      case OverlayKind.goal:
        _onFollow(FollowEvent(viewerId: 'mira', viewerName: 'Mira', source: EventSource.test));
        _onFollow(FollowEvent(viewerId: 'neo', viewerName: 'Neo', source: EventSource.test));
        _seedGifts(viewers);
      case OverlayKind.viewerAction:
        _onAction(ViewerActionEvent(
          viewerName: 'Mira',
          giftName: 'Роза',
          actionId: 'to_first_level',
          actionTitle: 'На первый уровень',
          result: 'Комната 37 → 1',
          ok: true,
          test: true,
        ));
      default:
        _seedGifts(viewers);
    }
  }

  void _vote(StatsBucket b, String viewerId, String name, String option) {
    b.votes[viewerId] = option;
    b.names[viewerId] = name;
  }

  void _seedGifts(List<(String, String)> viewers) {
    const gifts = [('5655', 'Роза', 1, 5), ('5487', 'Сердечко', 5, 3), ('7934', 'Сердце', 1, 47), ('6064', 'Лев', 29999, 1)];
    for (var i = 0; i < gifts.length; i++) {
      final g = gifts[i];
      _onGift(GiftEvent(
        id: generateEventId(),
        createdAt: DateTime.now(),
        source: EventSource.test,
        viewerName: viewers[i].$2,
        viewerId: viewers[i].$1,
        giftName: g.$2,
        giftId: g.$1,
        diamonds: g.$3,
        count: g.$4,
        sourceKey: 'test-seed-${generateEventId()}',
      ));
    }
  }
}

/// Сохранённая статистика эфира (восстанавливается после перезапуска).
Future<StatsBucket?> loadLiveStats(JsonStore store) async {
  try {
    final json = await store.read(StreamStatsController.fileName);
    return json == null ? null : StatsBucket.fromJson(json);
  } catch (_) {
    return null;
  }
}
