import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Этап готовности игрового режима.
enum ModeStage {
  planned('В планах'),
  inDevelopment('В разработке'),
  ready('Готов');

  const ModeStage(this.label);

  final String label;
}

/// Описание игрового режима. Новые режимы добавляются по одному
/// в [gameModes]; запуск режима появится на следующих этапах.
class GameModeInfo {
  const GameModeInfo({
    required this.id,
    required this.title,
    required this.description,
    required this.stage,
  });

  final String id;
  final String title;
  final String description;
  final ModeStage stage;
}

const gameModes = <GameModeInfo>[
  GameModeInfo(
    id: parkourModeId,
    title: 'Dirron Parkour: 100 комнат',
    description: 'Сто паркур-комнат с растущей сложностью. Подарки зрителей '
        'помогают пройти комнату или, наоборот, мешают: 24 действия.',
    stage: ModeStage.ready,
  ),
  GameModeInfo(
    id: skyModeId,
    title: 'Небесный разлом',
    description: 'Полёт на элитрах через кольца над небесными островами: 6 секторов, '
        'контрольные точки, 10 действий зрителей — ветер, гроза, слалом, ангел-хранитель.',
    stage: ModeStage.ready,
  ),
  GameModeInfo(
    id: 'maze_escape',
    title: 'Побег из лабиринта',
    description: 'Нужно выбраться из лабиринта, а зрители подарками открывают '
        'проходы, ставят ловушки и перестраивают стены.',
    stage: ModeStage.planned,
  ),
  GameModeInfo(
    id: 'evolution_chaos',
    title: 'Evolution Chaos',
    description: 'Мир постепенно мутирует: подарки запускают эволюцию мобов, '
        'блоков и правил игры.',
    stage: ModeStage.planned,
  ),
];

const parkourModeId = 'dirron_parkour_100';
const skyModeId = 'sky_rift';

/// Открытый на вкладке «Режимы» режим (`null` — сетка режимов).
final openModeProvider = NotifierProvider<OpenModeController, String?>(OpenModeController.new);

class OpenModeController extends Notifier<String?> {
  @override
  String? build() => null;

  void open(String? modeId) => state = modeId;
}
