import 'dart:async';

import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app.dart';
import 'bootstrap.dart';
import 'core/initial_data.dart';
import 'core/storage/app_paths.dart';
import 'core/storage/json_file_store.dart';
import 'features/overlays/overlay_server.dart';
import 'features/chat/chat_voice.dart';
import 'features/parkour/gift_catalog.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // %APPDATA%\Dirronlive — данные текущего пользователя Windows.
  final store = FileJsonStore(resolveDataDirectory());
  final data = await loadInitialData(store);
  final container = createAppContainer(data);
  // Оверлеи для TikTok LIVE Studio: http://localtest.me:8777/overlay/…
  unawaited(container.read(overlayServerProvider.notifier).start());
  // Чат TikTok → чат Minecraft и озвучка.
  startChatRelay(container);
  // Полный список подарков TikTok — со своего компьютера, без эфира.
  unawaited(container.read(giftCatalogProvider.notifier).autoSync().catchError((Object _) {}));

  runApp(
    UncontrolledProviderScope(
      container: container,
      child: const DirronliveApp(),
    ),
  );
}
